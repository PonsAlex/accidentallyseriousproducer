CLASSIC HOUSE — 124 BPM ARRANGEMENT TEMPLATE
=============================================

What this is
------------

A structural template for an extended classic house arrangement in FL Studio:
124 BPM, 4/4, 224 bars (about 7 minutes 14 seconds). It gives you the timeline,
the track names and the automation rows. It does not give you the music.

Everything here is a starting point, not a finished track.


READ THIS BEFORE TRUSTING THE AUTOMATIONS
-----------------------------------------

The automation clips exist, they are assigned to real parameters, and they move.
They are also generic: the sidechain ducking in particular reacts to the kick
as its source, and how much it ducks depends on what you load into the other
tracks. A hard kick and a dense bass will need different numbers than a soft kick
and a sparse bass.

Treat every value in the playbook as a starting point, then listen and adjust:

  - Sidechain (AUT 04 to AUT 07): 3-5 dB on bass and 1-3 dB on chords are mild by
    design. If your kick is short and clicky, the ducking may do almost nothing;
    if your bass is long, the drop may still sound muddy. Move the numbers, not
    the clips.
  - LPF cycles (AUT 01 to AUT 03): 400 Hz to 5 kHz suits a bright piano patch. A
    darker patch may need the floor higher, or the sweep becomes inaudible.
  - HPF builds (AUT HPF Build 1/2) and reverb swells (AUT Reverb 1/2): these are
    shaped by the material. A build that already sounds tense does not need the
    filter to travel as far.

Automation that is routed correctly but tuned wrong sounds worse than no
automation, because you stop hearing the problem and start trusting the clip.


What is inside
--------------

  Classic House 124 - TEMPLATE - Breaking_the_8-Bar_Loop.flp
      The FL Studio project. FL Studio 2026 (26.1.7) format.

  Breaking the 8-Bar Loop.pptx
      A fourteen-slide visual guide to horizontal arrangement and subtractive
      sculpting in FL Studio, built around this exact template.

  Horizontal Arrangement Playbook (EN).pdf
      The written reasoning: why building the climax first and subtracting is
      faster than stacking an eight-bar loop forever.


The project
-----------

  24 named Playlist tracks, 13 of them musical elements:

      KICK_4OTF          CLAP_SNARE        HATS_CLOSED      HATS_OPEN
      SHAKER_TAMB        PERC_CONGAS       BASS_HOUSE       PIANO_HOUSE
      ORGAN_STABS        PADS_DISCO        VOCAL_CHOPS      FX_IMPACTS
      DRUM_FILLS

  plus eleven automation rows: two HPF build ramps, two reverb swells, the LPF
  cycles on piano, organ and pads, and sidechain ducking for bass, piano, organ
  and pads.

  The arrangement runs 1 to 224 bars in ten sections:

      Intro 1     1-16        Drop 1B    81-112
      Intro 2    17-32        Break     113-128
      Build 1    33-48        Build 2   129-144
      Drop 1A    49-80        Drop 2    145-176
                              Outro 1   177-208
                              Outro 2   209-224

  Micro-breaks sit at 31-32, 45-48, 79-80, 111-112, 141-144 and 175-176, where
  the low end drops out for a beat.


What it does not contain
------------------------

  No samples. No plugins. No MIDI notes. The patterns are empty placeholders
  named after their track, so the arrangement opens with the structure visible
  and the music yours to write.

  If a pattern looks empty, that is correct. It is a slot, not a loop.


About the slides
----------------

  Breaking the 8-Bar Loop is a picture deck: each of its fourteen slides is one
  full-page image, so the text is not selectable, searchable or copyable. Read
  it as a presentation, not as a reference document. If you need the words, the
  PDF playbook covers the same ground in text.


How to start
------------

  1. Open the .flp. Set your sample rate and confirm 124 BPM.
  2. Fill the Channel Rack: one instrument per Playlist track, same names.
  3. Write the full 100% version inside Drop 1B (bars 81-112) first.
  4. Duplicate it across the timeline, then delete down to the matrix.
     Subtracting from a finished block is faster than building up.
  5. Draw or retune the automations last, and check the break and both drops by
     ear before you trust them.


Licence
-------

Use it, change it, release what you make with it. No credit required, no
attribution, no license fee. If it helps you finish something, that is the
whole point.

Accidentally Serious Producer — accidentallyseriousproducer.com
